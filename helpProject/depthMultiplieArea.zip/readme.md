操作步骤:

1. 将处理文件拖到res目录下
2. 使用命令`pip install openpyxl安`装python需要的库文件
3. 运行程序,会在res目录下产生处理后的结果文件`result.xlsx`

